package org.cnu.realcoding;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstSpringBootApp5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
