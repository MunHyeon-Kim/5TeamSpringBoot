package org.cnu.realcoding;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstSpringBootApp5Application {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstSpringBootApp5Application.class, args);
	}

}
